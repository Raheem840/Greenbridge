(function () {
  // Create a container for the Three.js scene behind everything
  const container = document.createElement("div");
  container.style.position = "fixed";
  container.style.top = "0";
  container.style.left = "0";
  container.style.width = "100%";
  container.style.height = "100%";
  container.style.pointerEvents = "none";
  container.style.zIndex = "-1"; // Place behind all content
  document.body.appendChild(container);

  // Dynamically load Three.js if it isn't already present
  if (typeof THREE === "undefined") {
    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";
    script.onload = init;
    document.head.appendChild(script);
  } else {
    init();
  }

  // Helper: Create a shuriken texture using canvas
  function createShurikenTexture() {
    const size = 64;
    const canvas = document.createElement("canvas");
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext("2d");

    // Center the drawing context
    ctx.clearRect(0, 0, size, size);
    ctx.translate(size / 2, size / 2);

    // Blue shuriken color
    ctx.fillStyle = "#a9a9a9";

    // Draw a 4-armed star (a basic shuriken shape)
    const spikes = 4;
    const outerRadius = (size / 2) * 0.8;
    const innerRadius = outerRadius / 2;
    let rot = (Math.PI / 2) * 3;
    const step = Math.PI / spikes;
    ctx.beginPath();
    ctx.moveTo(0, -outerRadius);
    for (let i = 0; i < spikes; i++) {
      const x1 = Math.cos(rot) * outerRadius;
      const y1 = Math.sin(rot) * outerRadius;
      ctx.lineTo(x1, y1);
      rot += step;
      const x2 = Math.cos(rot) * innerRadius;
      const y2 = Math.sin(rot) * innerRadius;
      ctx.lineTo(x2, y2);
      rot += step;
    }
    ctx.closePath();
    ctx.fill();

    // Reset transformation and create texture
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    const texture = new THREE.Texture(canvas);
    texture.needsUpdate = true;
    return texture;
  }

  // Helper: Generate a random x value that avoids the center region
  function randomX(range) {
    // range is half the total width (e.g., 100 if full width is 200)
    let x = (Math.random() - 0.5) * range * 2;
    // Define a "center" band where we don't want many particles
    const centerBand = 30;
    if (Math.abs(x) < centerBand) {
      // Push x outwards while keeping sign
      x =
        (x < 0 ? -1 : 1) * (centerBand + Math.random() * (range - centerBand));
    }
    return x;
  }

  function init() {
    // Setup scene, camera, and renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      window.innerWidth / window.innerHeight,
      1,
      1000
    );
    camera.position.z = 100;

    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    container.appendChild(renderer.domElement);

    // Create a particle system using a custom shuriken texture
    // Reduced particle count for fewer flakes appearing per second
    const flakeCount = 300;
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const speeds = [];
    for (let i = 0; i < flakeCount; i++) {
      // x is biased to avoid the center; y and z are random in a given range
      positions.push(
        randomX(100), // x: using a total width range of 200
        Math.random() * 200 - 100, // y: vertical position
        (Math.random() - 0.5) * 200 // z: depth position
      );
      // Each shuriken falls at its own speed
      speeds.push(Math.random() * 0.5 + 0.5);
    }
    geometry.setAttribute(
      "position",
      new THREE.Float32BufferAttribute(positions, 3)
    );
    geometry.setAttribute("speed", new THREE.Float32BufferAttribute(speeds, 1));

    // Use PointsMaterial with the custom shuriken texture.
    // Reduced size and increased transparency.
    const material = new THREE.PointsMaterial({
      map: createShurikenTexture(),
      size: 4, // Reduced size from previous version
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.5, // More transparent
      depthTest: false,
      alphaTest: 0.5,
    });

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);

    // Track mouse movement for interactive scene rotation
    let mouseX = 0,
      mouseY = 0;
    document.addEventListener("mousemove", function (event) {
      mouseX = (event.clientX - window.innerWidth / 2) * 0.05;
      mouseY = (event.clientY - window.innerHeight / 2) * 0.05;
    });

    // Animation loop: update particle positions and apply interactive rotation
    function animate() {
      requestAnimationFrame(animate);

      const positions = geometry.getAttribute("position");
      const speeds = geometry.getAttribute("speed");
      for (let i = 0; i < positions.count; i++) {
        positions.array[i * 3 + 1] -= speeds.array[i];
        // Reset particle to the top if it falls below a threshold
        if (positions.array[i * 3 + 1] < -100) {
          positions.array[i * 3 + 1] = 100;
          // Optionally reapply a new x position avoiding the center on reset
          positions.array[i * 3 + 0] = randomX(100);
        }
      }
      positions.needsUpdate = true;

      // Rotate the scene slightly based on mouse movement for interactivity
      scene.rotation.y = mouseX * 0.01;
      scene.rotation.x = mouseY * 0.01;

      renderer.render(scene, camera);
    }
    animate();

    // Update renderer and camera on window resize
    window.addEventListener("resize", function () {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    });
  }
})();
